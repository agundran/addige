<?php

echo "state_value is " . $_SESSION[ "state_value" ] . "</br>\n";
$_SESSION[ "state_value" ] = "BEGIN";

?>
