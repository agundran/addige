<?

define( 'MSG_LOG_NORMAL',  0 );
define( 'MSG_LOG_WARNING', 1 );
define( 'MSG_LOG_ERROR',   2 );

echo 'MSG_LOG_NORMAL '  . MSG_LOG_NORMAL  . "\n";
echo 'MSG_LOG_WARNING ' . MSG_LOG_WARNING . "\n";
echo 'MSG_LOG_ERROR '   . MSG_LOG_ERROR   . "\n";

?>
