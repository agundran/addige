<?

// ugly, but this is TelAmerica's customer name as it appears in the
// XML order file.
//define( 'TELAMERICA',    'TelAmerica Media' );
// in late June, TelAmerica started calling themselves Cadent Network
define( 'TELAMERICA',    'CADENT NETWORK' );

?>
